const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser')
const app = express();

app.use(bodyParser.json())
app.use(express.static('public'));

app.use(cors({
    origin:'*'
}));


app.get('/', (req, res) => {
    res.send('CARALHO');
});

app.get('/sobre', (req, res) => {
    res.send('Está é a pagina sobre');
});

app.get('/tarefas', (req, res) => {
    const tarefas = require('./public/tarefas.json');
    res.json(tarefas);
});

app.post('/novaTarefa', (req, res) => {
    res.send('A requesição POST para novaTarefa/ Chegou')
})


app.listen(3000,()=>{
    console.log('Servidor rodando em http://localhost:3000');
});